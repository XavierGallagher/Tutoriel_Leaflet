# Importation des differents packages necessaire pour la realisation il est important de noter 
# qu'ils doivent etre deja telecharge sur RStudio. 
list.of.packages <- c("shiny", "rgdal","leaflet", "RColorBrewer", "shinythemes", "ggplot2", "sp")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages) > 0) {install.packages(new.packages)}
lapply(list.of.packages, require, character.only=T)

library(shiny)
library(leaflet)
library(rgdal)
library(RColorBrewer)
library(shinythemes)
library(ggplot2)
library(sp)

#Les donnes sont situer dans deux fichiers differents. Les donnes de crimes depuis 1980, qui sont utiliser pour 
# la mise en place de graphiques interactif est en fichier CSV. Dans le cas des donnees cartographiques, elles sont
# En Fichier GeoJSON. Ce format contient un seul dossier, se qui facilite l'importation et la manipulation. 

DataMTL <- readOGR("data/MTL_Data.geojson")
DataExplore <-as.data.frame(DataMTL)



# Debut du fichier ui, soit le user interface. Il contient les details de la structure de l'APP
# Dans cette section, nous devons preciser quels contenus se retrouverons dans les differentes pages. 

# L'utilisation de tabsetPanel, permet d'utiliser differents onglets. 
ui <- fluidPage(
  titlePanel("Taux de Chômage à Montréal"), #<- titre principal de l'APP
  tabsetPanel(
    tabPanel("Carte par Aire de Diffusion", leafletOutput("DataMTL", height = 600, width = 1300)),
    tabPanel("Explorateur de données", dataTableOutput("DataExplore")),
    tabPanel("Explorateur Graphique", 
             sidebarLayout(
               sidebarPanel(
                 selectInput('xcol', 'variable x', choices = c("DENSI_POP", "REVENUTOTA", "REVENUTO_A", "REVMEDIANM", "REVMOYENME", 
                                                               "VALEURMOYE", "AUCUNCERTI", "V38", "ZTAUXDECH", "APIED", "BICYCLETTE", "AUTOMOBILE")),
                 
                 selectInput('ycol', 'variable y', choices = c("DENSI_POP", "REVENUTOTA", "REVENUTO_A", "REVMEDIANM", "REVMOYENME", 
                                                               "VALEURMOYE", "AUCUNCERTI", "V38", "ZTAUXDECH", "APIED", "BICYCLETTE", "AUTOMOBILE"))
               ),
               
               # Show a plot of the generated distribution
               mainPanel(
                 plotOutput("plotMTL")
               )
             )
             
    )
  
  
  ),
  theme = shinytheme("slate")
)

binV38<- c(0, 5, 10, 15, 20, 25, 30, 35, 40) # <- valeur des intervals en %
palV38 <- colorBin("YlOrRd", domain = DataMTL$binV38, bins = binV38) #<- choix de la palette de couleur
labelV38 <- sprintf(
  " Taux de Chômage: <strong>%s</strong> ",
  DataMTL$V38
) %>% lapply(htmltools::HTML)

binRevMed <- c(0, 50816, 101632, 152448, 203264, 254080, 304896, 355712, 406528)
palRevMed <- colorBin("YlOrRd", domain = DataMTL$REVMEDIANM, bins = binRevMed)
labelRevMed <- sprintf(
  " Revenu Médian: <strong>%s</strong> ",
  DataMTL$REVMEDIANM
) %>% lapply(htmltools::HTML)


server <- function(input, output, session) {
  output$DataMTL <- renderLeaflet({
    leaflet()%>%
      addProviderTiles(providers$OpenStreetMap.HOT, options= providerTileOptions(opacity = 0.99)) %>% 
      addPolygons(data = DataMTL,
                  group = "Chomage",
                  stroke = TRUE,
                  fillColor = ~palV38(V38),
                  weight = 2,
                  opacity = 1,
                  color = "grey", 
                  dashArray= "3",
                  fillOpacity = 0.7,
                  highlight = highlightOptions(
                    weight = 5,
                    color = "#666",
                    dashArray = "",
                    fillOpacity = 0.7,
                    bringToFront = TRUE),
                  label = labelV38,
                  labelOptions = labelOptions(
                    style = list("font-weight" = "normal", padding = "3px 8px"),
                    textsize = "15px",
                    direction = "auto")) %>% 
      addPolygons(data = DataMTL,
                  group = "RevMedian",
                  stroke = TRUE,
                  fillColor = ~palRevMed(REVMEDIANM),
                  weight = 2,
                  opacity = 1,
                  color = "grey", 
                  dashArray= "3",
                  fillOpacity = 0.7,
                  highlight = highlightOptions(
                    weight = 5,
                    color = "#666",
                    dashArray = "",
                    fillOpacity = 0.7,
                    bringToFront = TRUE),
                  label = labelRevMed,
                  labelOptions = labelOptions(
                    style = list("font-weight" = "normal", padding = "3px 8px"),
                    textsize = "15px",
                    direction = "auto"))  %>%
      
      addLayersControl(baseGroups = c("OSM (default)"),
                       overlayGroups = c("Chomage", "RevMedian"),
                       options = layersControlOptions(collapsed = FALSE)) %>%
      
      hideGroup("RevMedian")
  })
  
  # creation Event Map MTL
  observeEvent(input$DataMTL_groups,{
    DataMTL <- leafletProxy("DataMTL") %>% clearControls()
    if (input$DataMTL_groups == 'Chomage')
    {DataMTL <- DataMTL %>% addLegend(pal =  palV38, values = DataMTL$V38, opacity = 0.7, title = "Taux de Chômage",
                                      position = "bottomleft")}
    else if (input$DataMTL_groups == 'RevMedian')
    {DataMTL <- DataMTL %>% addLegend(pal = palRevMed, values = DataMTL$REVMEDIANM, 
                                      opacity = 0.7, title = "Revenu Médian",
                                      position = "bottomleft")}
    
  })
  
  output$DataExplore <- renderDataTable(
    DataExplore, 
    options = list(
      pageLength = 5)
  )
  selectedData  <- reactive({
    DataExplore[, c(input$xcol, input$ycol)]
  })
  output$plotMTL <- renderPlot({
    p <- ggplot(selectedData(), aes_string(x = input$xcol, y=input$ycol, color= input$ycol)) + 
      geom_point()  +  scale_color_distiller(palette = "RdPu") 
    
    print(p)
    
  })  
  
  
}
shinyApp(ui, server)



